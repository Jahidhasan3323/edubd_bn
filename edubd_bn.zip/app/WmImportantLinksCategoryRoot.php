<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;
class WmImportantLinksCategoryRoot extends Model
{
    
    
    
    protected $guarded = array();
}
