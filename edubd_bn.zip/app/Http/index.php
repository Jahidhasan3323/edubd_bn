<div style="width: 50%; margin: 100px auto">
    <h1 style="color: red" class="text-center">Opps,  The page not found your are looking for !</h1>
    <p>Please Enter valid url. or click <a href="../">here</a></p>
</div>