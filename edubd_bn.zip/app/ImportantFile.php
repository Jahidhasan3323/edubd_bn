<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImportantFile extends Model
{
     protected $guarded = array();
}
